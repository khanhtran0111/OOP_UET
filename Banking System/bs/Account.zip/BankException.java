
public class BankException extends java.lang.Exception {
    public BankException(String message) {
        super(message);
    }
}

